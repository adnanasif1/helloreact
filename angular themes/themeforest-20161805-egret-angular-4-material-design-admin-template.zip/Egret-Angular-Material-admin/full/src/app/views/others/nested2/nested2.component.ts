import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nested2',
  templateUrl: './nested2.component.html',
  styleUrls: ['./nested2.component.scss']
})
export class Nested2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
