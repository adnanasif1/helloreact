import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buttons',
  templateUrl: './app-buttons.component.html',
  styleUrls: ['./app-buttons.component.css']
})
export class AppButtonsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
